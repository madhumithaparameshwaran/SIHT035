"""
This file is part of Giswater 3
The program is free software: you can redistribute it and/or modify it under the terms of the GNU
General Public License as published by the Free Software Foundation, either version 3 of the License,
or (at your option) any later version.
"""

shared: 
shared actions, called from more than one specific button (shared actions)

tasks: 
task actions, actions called as background process

toolbars:
toolbar actions, called only from specific toolbar button

ui:
python files related to ui

utils:
utilities and tools used on core

models:
models

root:
init actions (load_project or btn_admin)