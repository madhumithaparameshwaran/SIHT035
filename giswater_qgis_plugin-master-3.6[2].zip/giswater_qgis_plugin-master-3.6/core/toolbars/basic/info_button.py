"""
This file is part of Giswater 3
The program is free software: you can redistribute it and/or modify it under the terms of the GNU
General Public License as published by the Free Software Foundation, either version 3 of the License,
or (at your option) any later version.
"""
# -*- coding: utf-8 -*-
import os
import re
import json
from functools import partial

from qgis.PyQt.QtCore import QPoint, Qt
from qgis.PyQt.QtGui import QColor, QCursor, QIcon
from qgis.PyQt.QtWidgets import QAction, QMenu
from qgis.core import QgsApplication, QgsGeometry, QgsMapToPixel, QgsPointXY

from ...shared import info
from ...shared.info import GwInfo
from ...toolbars.maptool import GwMaptool
from ...threads.toggle_valve_state import GwToggleValveTask
from ...utils import tools_gw
from .... import global_vars
from ....libs import lib_vars, tools_qgis, tools_os, tools_qt


class GwInfoButton(GwMaptool):
    """ Button 37: Info """

    def __init__(self, icon_path, action_name, text, toolbar, action_group):

        super().__init__(icon_path, action_name, text, toolbar, action_group)

        self.rubber_band = tools_gw.create_rubberband(global_vars.canvas)
        self.tab_type = None
        # Used when the signal 'signal_activate' is emitted from the info, do not open another form
        self.block_signal = False
        self.previous_info_feature = None
        self.action_name = action_name


    # region QgsMapTools inherited
    """ QgsMapTools inherited event functions """

    def keyPressEvent(self, event):

        if event.key() == Qt.Key_Escape:
            for rb in self.rubberband_list:
                tools_gw.reset_rubberband(rb)
            tools_gw.reset_rubberband(self.rubber_band)
            self.action.trigger()
            return


    def canvasMoveEvent(self, event):
        pass


    def canvasReleaseEvent(self, event):

        self._get_info(event)


    def activate(self):

        if info.is_inserting:
            msg = "You cannot insert more than one feature at the same time, finish editing the previous feature"
            tools_qgis.show_message(msg)
            super().deactivate()
            return

        # Check action. It works if is selected from toolbar. Not working if is selected from menu or shortcut keys
        if hasattr(self.action, "setChecked"):
            self.action.setChecked(True)
        # Change map tool cursor
        self.cursor = QCursor()
        self.cursor.setShape(Qt.WhatsThisCursor)
        self.canvas.setCursor(self.cursor)
        self.rubberband_list = []
        self.tab_type = 'data'


    def deactivate(self):

        if hasattr(self, 'rubberband_list'):
            for rb in self.rubberband_list:
                tools_gw.reset_rubberband(rb)
        if hasattr(self, 'dlg_info_feature'):
            tools_gw.reset_rubberband(self.rubber_band)

        super().deactivate()

    # endregion

    # region private functions

    def _reactivate_map_tool(self):
        """ Reactivate tool """

        self.block_signal = True
        info_action = self.iface.mainWindow().findChildren(QAction, self.action_name)[-1]
        info_action.trigger()


    def _reset_rubber_bands(self):
        for rb in self.rubberband_list:
            tools_gw.reset_rubberband(rb)
        if hasattr(self, "rubber_band"):
            tools_qgis.reset_rubber_band(self.rubber_band)


    def _get_layers_from_coordinates(self, point, rb_list, tab_type=None):

        cursor = QCursor()
        x = cursor.pos().x()
        y = cursor.pos().y()
        click_point = QPoint(x + 5, y + 5)

        visible_layers = tools_qgis.get_visible_layers(as_str_list=True)
        scale_zoom = self.iface.mapCanvas().scale()

        # Get layers under mouse clicked
        extras = f'"pointClickCoords":{{"xcoord":{point.x()}, "ycoord":{point.y()}}}, '
        extras += f'"visibleLayers":{visible_layers}, '
        extras += f'"zoomScale":{scale_zoom} '
        body = tools_gw.create_body(extras=extras)
        json_result = tools_gw.execute_procedure('gw_fct_getlayersfromcoordinates', body, rubber_band=self.rubber_band)
        if not json_result or json_result['status'] == 'Failed':
            return False

        # hide QMenu identify if no feature under mouse
        len_layers = len(json_result['body']['data']['layersNames'])
        if len_layers == 0:
            return False

        self.icon_folder = self.plugin_dir + '/icons/'

        # Right click main QMenu
        main_menu = QMenu()

        # Create one menu for each layer
        for layer in json_result['body']['data']['layersNames']:
            layer_name = tools_qgis.get_layer_by_tablename(layer['layerName'])
            icon_path = self.icon_folder + layer['icon'] + '.png'
            if os.path.exists(str(icon_path)):
                icon = QIcon(icon_path)
                sub_menu = main_menu.addMenu(icon, layer_name.name())
            else:
                sub_menu = main_menu.addMenu(layer_name.name())
            # Create one QAction for each id
            for feature in layer['ids']:
                if 'label' in feature:
                    label = str(feature['label'])
                else:
                    label = str(feature['id'])
                action = QAction(label, None)
                action.setProperty('feature_id', str(feature['id']))
                sub_menu.addAction(action)
                action.triggered.connect(partial(self._get_info_from_selected_id, action, tab_type))
                action.hovered.connect(partial(self._draw_by_action, feature, rb_list))

        main_menu.addSeparator()
        # Identify all
        cont = 0
        for layer in json_result['body']['data']['layersNames']:
            cont += len(layer['ids'])
        action = QAction(f'Identify all ({cont})', None)
        action.hovered.connect(partial(self._identify_all, json_result, rb_list))
        main_menu.addAction(action)
        main_menu.addSeparator()

        # Open/close valve
        valve = json_result['body']['data'].get('valve')
        if valve:
            valve_id = valve['id']
            valve_text = valve['text']
            valve_table = valve['tableName']
            valve_value = valve['value']
            action_valve = QAction(f"{valve_text}", None)
            action_valve.triggered.connect(partial(self._toggle_valve_state, valve_id, valve_table, valve_value))
            action_valve.hovered.connect(partial(self._reset_rubber_bands))
            main_menu.addAction(action_valve)
            main_menu.addSeparator()

        # Open/close valve in netscenario
        valve_netscenario = json_result['body']['data'].get('valve_netscenario')
        if valve_netscenario:
            valve_netscenario_id = valve_netscenario['id']
            netscenario_id = valve_netscenario['netscenario_id']
            valve_netscenario_text = valve_netscenario['text']
            valve_netscenario_table = valve_netscenario['tableName']
            valve_netscenario_value = valve_netscenario['value']
            action_valve_netscenario = QAction(f"{valve_netscenario_text}", None)
            if valve_netscenario_id:
                action_valve_netscenario.triggered.connect(partial(self._toggle_valve_state_netscenario, netscenario_id, valve_netscenario_id, valve_netscenario_table, valve_netscenario_value))
            action_valve_netscenario.hovered.connect(partial(self._reset_rubber_bands))
            main_menu.addAction(action_valve_netscenario)
            main_menu.addSeparator()

        main_menu.aboutToHide.connect(self._reset_rubber_bands)
        main_menu.exec_(click_point)


    def _identify_all(self, complet_list, rb_list):

        tools_gw.reset_rubberband(self.rubber_band)
        for rb in rb_list:
            tools_gw.reset_rubberband(rb)
        for layer in complet_list['body']['data']['layersNames']:
            for feature in layer['ids']:
                points = []
                list_coord = re.search('\((.*)\)', str(feature['geometry']))
                coords = list_coord.group(1)
                polygon = coords.split(',')
                for i in range(0, len(polygon)):
                    x, y = polygon[i].split(' ')
                    point = QgsPointXY(float(x), float(y))
                    points.append(point)
                rb = tools_gw.create_rubberband(self.canvas)
                polyline = QgsGeometry.fromPolylineXY(points)
                rb.setToGeometry(polyline, None)
                rb.setColor(QColor(255, 0, 0, 100))
                rb.setWidth(5)
                rb.show()
                rb_list.append(rb)


    def _toggle_valve_state(self, valve_id, table_name, value):
        """ Open or closes a valve. If parameter 'utils_graphanalytics_automatic_trigger' is true,
        also updates mapzones in a thread """

        # Build function body
        feature = f'"id":"{valve_id}", '
        feature += f'"tableName":"{table_name}", '
        feature += f' "featureType":"node" '
        extras = f'"fields":{{"closed": "{value}"}}'
        body = tools_gw.create_body(feature=feature, extras=extras)

        # Get utils_graphanalytics_automatic_trigger param
        row = tools_gw.get_config_value("utils_graphanalytics_automatic_trigger", table='config_param_system')
        thread = row[0] if row else None
        if thread:
            thread = json.loads(thread)
            thread = tools_os.set_boolean(thread['status'], default=False)

        # If param is false don't create thread
        if not thread:
            tools_gw.execute_procedure('gw_fct_setfields', body)
            tools_qgis.refresh_map_canvas()
            return

        # If param is true show question and create thread
        msg = "You closed a valve, this will modify the current mapzones and it may take a little bit of time."
        if lib_vars.user_level['level'] in ('1', '2'):
            msg += " Would you like to continue?"
            answer = tools_qt.show_question(msg)
        else:
            tools_qgis.show_info(msg)
            answer = True

        if answer:
            params = {"body": body}
            self.valve_thread = GwToggleValveTask("Update mapzones", params)
            QgsApplication.taskManager().addTask(self.valve_thread)
            QgsApplication.taskManager().triggerTask(self.valve_thread)


    def _toggle_valve_state_netscenario(self, netscenario_id, valve_id, table_name, value):
        """ Open or closes a valve in a netscenario """

        # Build function body
        feature = f'"id":"{netscenario_id}, {valve_id}", '
        feature += f'"tableName":"{table_name}" '
        # feature += f' "featureType":"node" '
        extras = f'"fields":{{"netscenario_id": "{netscenario_id}", "node_id": "{valve_id}","closed": "{value}"}}'
        body = tools_gw.create_body(feature=feature, extras=extras)

        tools_gw.execute_procedure('gw_fct_upsertfields', body)
        tools_qgis.refresh_map_canvas()


    def _draw_by_action(self, feature, rb_list, reset_rb=True):
        """ Draw lines based on geometry """

        for rb in rb_list:
            tools_gw.reset_rubberband(rb)
        if feature['geometry'] is None:
            return

        if reset_rb:
            tools_gw.reset_rubberband(self.rubber_band)
        tools_gw.draw_wkt_geometry(str(feature['geometry']), self.rubber_band, QColor(255, 0, 0, 100), 3)


    def _get_info_from_selected_id(self, action, tab_type):
        """ Set active selected layer """

        tools_gw.reset_rubberband(self.rubber_band)
        parent_menu = action.associatedWidgets()[0]
        layer = tools_qgis.get_layer_by_layername(parent_menu.title())
        if layer:
            layer_source = tools_qgis.get_layer_source(layer)
            self.iface.setActiveLayer(layer)
            tools_gw.init_docker()
            info_feature = GwInfo(self.tab_type)
            info_feature.signal_activate.connect(self._reactivate_map_tool)
            info_feature.get_info_from_id(table_name=layer_source['table'], feature_id=action.property('feature_id'), tab_type=tab_type)
            # Remove previous rubberband when open new docker
            if isinstance(self.previous_info_feature, GwInfo) and lib_vars.session_vars['dialog_docker'] is not None:
                tools_gw.reset_rubberband(self.previous_info_feature.rubber_band)
            self.previous_info_feature = info_feature


    def _get_info(self, event):

        for rb in self.rubberband_list:
            tools_gw.reset_rubberband(rb)

        if self.block_signal:
            self.block_signal = False
            return

        if event.button() == Qt.LeftButton:

            point = tools_qgis.create_point(self.canvas, self.iface, event)
            if point is False:
                return
            tools_gw.init_docker()
            info_feature = GwInfo(self.tab_type)
            info_feature.signal_activate.connect(self._reactivate_map_tool)
            info_feature.get_info_from_coordinates(point, tab_type=self.tab_type)
            # Remove previous rubberband when open new docker
            if isinstance(self.previous_info_feature, GwInfo) and lib_vars.session_vars['dialog_docker'] is not None:
                tools_gw.reset_rubberband(self.previous_info_feature.rubber_band)
            self.previous_info_feature = info_feature

        elif event.button() == Qt.RightButton:
            point = tools_qgis.create_point(self.canvas, self.iface, event)
            if point is False:
                return

            self._get_layers_from_coordinates(point, self.rubberband_list, self.tab_type)

    # endregion
