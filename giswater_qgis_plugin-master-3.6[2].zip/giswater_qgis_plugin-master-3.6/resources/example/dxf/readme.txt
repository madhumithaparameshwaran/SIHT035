IMPORT DXF FILES EXAMPLE
------------------------

This example works with on example project of Giswater (WS).
To execute this import using toolbox function, first features must be deleted on database.
To do this use file ddl.sql
That's all
Enjoy it!!!